dlib instllation is complicated and time consuming, better to sleep !

https://stackoverflow.com/questions/42129142/dlib-installation-python-2-7
https://gist.github.com/Geoyi/d9fab4f609e9f75941946be45000632b
https://stackoverflow.com/questions/41912372/dlib-installation-on-windows-10
https://pypi.org/project/dlib/
https://www.pyimagesearch.com/2017/03/27/how-to-install-dlib/

neural-nw
https://pypi.org/project/face_recognition/#description
