

<!DOCTYPE HTML>
<!-- <html> -->
   <head>
      <title>simplestyle_3 - a page</title>
      <meta name="description" content="website description" />
      <meta name="keywords" content="website keywords, website keywords" />
      <meta http-equiv="content-type" content="text/html; charset=windows-1252" />
      <link rel="stylesheet" type="text/css" href="css/style1.css" />
   </head>
   <body>
      <div id="main">
         <div id="header">
            <div id="logo">
               <div id="logo_text">
                  <!-- class="logo_colour", allows you to change the colour of the text -->
                  <h1><a href="index.html">Add<span class="logo_colour">Element</span></a></h1>
                  <h2> Donate someting for the needy..</h2>
               </div>
            </div>
            <div id="menubar">
               <ul id="menu">
                  <!-- put class="selected" in the li tag for the selected page - to highlight which page you're on -->
                  <li><a href="index.html">Home</a></li>
                  <li><a href="index.php">update</a></li>
                  <li class="selected"><a href="#">Add element</a></li>
                  <!-- <li><a href="another_page.html">Admin</a></li> -->
                  <li><a href="contact.html">Contact Us</a></li>
               </ul>
            </div>
         </div>
         <div id="site_content">

            <div id="content">
               <!-- insert the page content here -->
               <h1>Donate Now ! </h1>
               <form action="add-element.php" method="post" >
                  <!DOCTYPE html>
                  <html>
                     <head>
                        <style>
                           table, th, td {
                           /* border: 1px solid black; */
                           background: transparent;
                           }
                        </style>
                     </head>
                     <body>
                        <table style="width:130%">
                           <!-- <tr>
                              <th >Firstname</th>
                              <th >Lastname</th>
                              <th >Age</th>
                           </tr> -->
                           <tr>
                              <td>
                                 <select name = "dropdown">
                                    <option value = "Food" selected>Food</option>
                                    <option value = "med">Medicine</option>
                                    <option value = "cloth">Cloth</option>
                                 </select>
                              </td>
                              <td>Name: <input type = "text" name = "name" value ="Appu" />
                              </td>
                              <td>contact 1:<input type="text" name = "contact1"  value ="9895648722" pattern="[789][0-9]{9}"/>
                              </td>
                           </tr>
                           <tr>
                              <td><input type = "checkbox" name = "urgent" value = "1"> URGENT!</td>
                              <td>Address <input type = "text" name = "address" value ="House No, abc P.O, Calicut, Kerala" /></td>
                              <td>contact 2: <input type="text" name = "contact2"  value ="9895648723" pattern="[789][0-9]{9}"/></td>
                           </tr>
                           <tr>
                              <td> </td>
                              <td> Expiry: <input type="date" name="exday" > </td>
                              <td>Quantity <input type = "text" name = "qty" value ="2 Kg" /></td>
                           </tr>
                           <tr>
                              <td> </td>
                              <td>Description : <textarea rows = "3" cols = "30" name="description">
                                 Enter description here...
                                 </textarea>
                              </td>
                              <td> </td>
                           </tr>
                        </table>
                     </body>
                  </html>
                  <br>
                  <br />
                  <input type = "submit" name = "submit" value = "Submit" />
                  <input type = "reset" name = "reset"  value = "Reset" />

               </form>
            </div>
         </div>
         <div id="footer">
            <p><a href="index.html">Home</a> </p>

         </div>
         <p>&nbsp;</p>
      </div>
   </body>
</html>
<?php
require('db.php');
session_start();
  // If form submitted, insert values into the database.
  if (isset($_POST['submit'])){

  $dropdown = stripslashes($_REQUEST['dropdown']); // removes backslashes
  $name = stripslashes($_REQUEST['name']);
  $contact1 = stripslashes($_REQUEST['contact1']); // removes backslashes
  $urgent = stripslashes($_REQUEST['urgent']); // removes backslashes
  $contact2 = stripslashes($_REQUEST['contact2']);
  $address = stripslashes($_REQUEST['address']);
  $exday = stripslashes($_REQUEST['exday']);
  $qty = stripslashes($_REQUEST['qty']);
  $description = stripslashes($_REQUEST['description']);
// echo "$dropdown";
// echo "*********";
// echo "$name";
// echo "$contact1";
// echo "$urgent";
// echo "$address";
// echo "$exday";
// echo "$qty";
// echo "$description";
// echo "$contact2";
// $query = "INSERT INTO `item_list` (`slno`, `item`, `name`, `contact1`, `urgent`, `contact2`, `address`, `exday`, `qty`, `description`) VALUES ('$dropdown', '$name', '$contact1','$urgent' ,'$contact2','$address', '$exday','$qty','$description')";
$query = "INSERT into item_list (item, name, contact1, urgent, contact2, address, exday, qty, description) VALUES ('$dropdown', '$name', '$contact1','$urgent' ,'$contact2','$address', '$exday','$qty','$description')";
echo "$query";
// $result = mysqli_query($con,$query);
// echo "$result";
if (mysqli_query($con, $query)) {
    echo "New record created successfully";
} else {
    echo "Error: " . $query . "<br>" . mysqli_error($con);
}
}

?>
