<?php
include("auth.php"); //include auth.php file on all secure pages
?>
<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<title>Welcome Admin</title>
<link rel="stylesheet" href="css/style1.css" />
</head>
<body>
<div class="form">
<p>Welcome <?php echo $_SESSION['username']; ?>!</p>
<p>This is secure area.</p>
<!DOCTYPE HTML>
<html>
<head>

  <meta name="description" content="website description" />
  <meta name="keywords" content="website keywords, website keywords" />
  <meta http-equiv="content-type" content="text/html; charset=windows-1252" />
  <link rel="stylesheet" type="text/css" href="css/style1.css" />
</head>
<body>
  <div id="main">
    <div id="header">
      <div id="logo">
        <div id="logo_text">
          <!-- class="logo_colour", allows you to change the colour of the text -->
          <h1><a href="index.html"><span class="logo_colour">Admin Console</span></a></h1>
          <h2>Administrative access to Website</h2>
        </div>
      </div>
      <div id="menubar">
        <ul id="menu">
          <!-- put class="selected" in the li tag for the selected page - to highlight which page you're on -->
          <li><a href="index.html">Home</a></li>
          <li ><a href="index.php">Updates</a></li>
          <li class="selected"><a href="#">Admin</a></li>
          <li><a href="contact.html">Contact Us</a></li>
        </ul>
      </div>
    </div>
    <div id="site_content">
      <div id="sidebar_container">
      </div>
      <div id="content">
        <h1>User Management</h1>
        <p>admin - 0 | volunter - 1 | users - 2 | block - 10</p>
        <table style="width:130%; border-spacing:0;">
          <table><tr>
                  <th style="text-align: center;">sl-No</th>
                  <th style="text-align: center;">user</th>
                  <th style="text-align: center;">level</th>
                  <th style="text-align: center;">Mail id</th>
                  <th style="text-align: center;">Created On</th>
                  <th style="text-align: center;">Delete user</th>
                  <th style="text-align: center;">Functions</th>
                </tr>
                <tr>
                  <b>
        <?php
        ini_set('display_errors', 1);
        ini_set('display_startup_errors', 1);
        error_reporting(E_ALL);
        require('db.php');
        $con = new mysqli("localhost","root","12","food-med-cloth");
          if ($con->connect_errno) {
              echo "Failed to connect to MySQL: (" . $con->connect_errno . ") " . $con->connect_error;
          }
          //$sql = "SHOW TABLES";
          //
          //
          // show items to picup
          //
          //
          $sql = "select * from users";  //edit your table name here
          // $res = $con->query($sql);
         if ($result = $con->query($sql)) {
             /* fetch associative array */
             while ($row = $result->fetch_assoc()) {
                 $user1 = $row["id"];
                 $user2 = $row["username"];
                 $user3 = $row["level"];
                 $user4 = $row["email"];
                 $user5 = $row["trn_date"];
                 echo "
                        <tr>
                        <td>".$user1."</td>
                        <td>".$user2."</td>
                        <td>".$user3."</td>
                        <td>".$user4."</td>
                        <td>".$user5."</td>
                        <td style='text-align:center;'>
                            <form action='' method='post'>
                            <button class='btn' type='submit' name='user_del' value='".$user1."'>Delete user</button> </td><td>
                            <button class='btn' type='submit' name='user_AV' value='".$user1."'>Add as volunteer</button><br>
                            <button class='btn' type='submit' name='user_RV' value='".$user1."'>Remove volunteer </button><br>
                            <button class='btn' type='submit' name='user_USR' value='".$user1."'>&nbsp;&nbsp;Block User </button>
                            <br>
                            <button class='btn' type='submit' name='user_UN_USR' value='".$user1."'>&nbsp;&nbsp;UnBlock User </button>
                            </form>
                        </td>
                      </tr>";
             }
             /* free result set */
             $result->free();
         }
        ?></table>
        <h1>Inventory Management</h1>
           <?php
           //
           //
           // Small  table
           //
           //
        if (isset($_POST['user_del'])) {
            $user_del = stripslashes($_REQUEST['user_del']); // removes backslashes
            // echo "$vol_page";
            $query99 = "DELETE FROM users WHERE id='$user1'";
            $result99 = $con->query($query99);
            echo '<script language="javascript">';
            echo 'alert("User Deleted !!")';
            echo '</script>';
        }
        if (isset($_POST['user_AV'])) {
            $user_GP = stripslashes($_REQUEST['user_AV']); // removes backslashes
            echo "$user_GP";
            $query99 = "UPDATE users SET level = 1 WHERE id='$user_GP'";
            $result99 = $con->query($query99);
            // $result = mysqli_query($con,$query);
            // echo "$result";
            echo '<script language="javascript">';
            echo 'alert("User Promoted !!")';
            echo '</script>';
        }
        if (isset($_POST['user_RV'])) {
            $user_RV = stripslashes($_REQUEST['user_RV']); // removes backslashes
            echo "$user_RV";
            $query99 = "UPDATE users SET level = 2 WHERE id='$user_RV'";
            $result99 = $con->query($query99);
        echo '<script language="javascript">';
            echo 'alert("User Demorted !!")';
            echo '</script>';
        }
        if (isset($_POST['user_USR'])) {
            $user_USR = stripslashes($_REQUEST['user_USR']); // removes backslashes
            $query99 = "UPDATE users SET level = 10 WHERE id='$user_USR'";
            $result99 = $con->query($query99);
            echo '<script language="javascript">';
            echo 'alert("BLOCKED the User !!")';
            echo '</script>';
        }
        if (isset($_POST['user_UN_USR'])) {
            $user_UN_USR = stripslashes($_REQUEST['user_UN_USR']); // removes backslashes
            $query991 = "UPDATE users SET level = 2 WHERE id='$user_UN_USR'";
            $result991 = $con->query($query991);
            echo '<script language="javascript">';
            echo 'alert("UNBLOCKED the User !!")';
            echo '</script>';
        }

        else {
          echo "-NO ACTION:2028";
      }
    ?>
    <!--  -->
    <!--  -->
    <!--  -->
    <!--  -->
    <!--  -->
    <!--  -->
    <!--  -->
    <!--  -->
<table>
    <?php

    $sql = "select * from item_list";  //edit your table name here
    // $res = $con->query($sql);
    if ($result = $con->query($sql)) {
       /* fetch associative array */
       while ($row = $result->fetch_assoc()) {
           $field0name = $row["slno"];
           $field1name = $row["item"];
           $field2name = $row["address"];
           $field3name = $row["qty"];
           // $field4name = $row["col4"];
           // $field5name = $row["col5"];
           echo "
                  <tr>
                  <td>".$field0name."</td>
                  <td>".$field1name."</td>
                  <td>".$field2name."</td>
                  <td>".$field3name."</td>
                  <td>
                      <form action='' method='post'>
                      <button class='btn' type='submit' name='Remove-admin' value='".$field0name."'>Remove fraud/duplicate</button>
                      </form>

                  </td>
                </tr>";
       }
       /* free result set */
       $result->free();
    }
    ?></table>

    <?php
    //
    //
    // Small  table
    //
    //
 if (isset($_POST['Remove-admin'])) {
     echo "///removing///";
     $ra = stripslashes($_REQUEST['Remove-admin']); // removes backslashes
echo "$ra";
     try {
       $query_del = "DELETE FROM item_list WHERE slno='$ra'";
       $result_del = $con->query($query_del);

     } catch (Exception $e) {

     }
   }
     ?>
      </div>
    </div>
    <div id="footer">
      <p><a href="index.html">Home</a> | <a href="logout.php">Logout</a>

      </p>
      <!-- <p>Copyright &copy; simplestyle_3 | <a href="http://validator.w3.org/check?uri=referer">HTML5</a> | <a href="http://jigsaw.w3.org/css-validator/check/referer">CSS</a> | <a href="http://www.html5webtemplates.co.uk">HTML5 Web Templates</a></p> -->
    </div>
    <p>&nbsp;</p>
  </div>
</body>
</html>
<br /><br /><br /><br />

<br /><br /><br /><br />
</div>
</body>
</html>
