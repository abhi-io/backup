<?php
/*
to connect to Data Base
(IP, user, Passwd, DB name)
*/


$con = mysqli_connect("localhost","root","12","food-med-cloth");
// Check connection
if (mysqli_connect_errno())
  {
  echo "Failed to connect to MySQL: " . mysqli_connect_error();
  }
?>
