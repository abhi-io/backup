<?php
include("auth.php"); //include auth.php file on all secure pages
include("db.php");
?>
<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<title>Welcome Home</title>
<link rel="stylesheet" href="css/style1.css" />
</head>
<body>
<div class="form">
<p>Welcome <?php echo $_SESSION['username']; ?>!</p>
<p>This is secure area.</p>
<!DOCTYPE HTML>
<html>
<head>
  <title>simplestyle_3 - examples</title>
  <meta name="description" content="website description" />
  <meta name="keywords" content="website keywords, website keywords" />
  <meta http-equiv="content-type" content="text/html; charset=windows-1252" />
  <link rel="stylesheet" type="text/css" href="css/style1.css" />
</head>
<body>
  <div id="main">
    <div id="header">
      <div id="logo">
        <div id="logo_text">
          <!-- class="logo_colour", allows you to change the colour of the text -->
          <h1><a href="index.html">Sharing<span class="logo_colour">is caring</span></a></h1>
          <h2>Simple. Contemporary. Website Template.</h2>
        </div>
      </div>
      <div id="menubar">
        <ul id="menu">
          <!-- put class="selected" in the li tag for the selected page - to highlight which page you're on -->
          <li><a href="index.html">Home</a></li>
          <li class="selected"><a href="examples.html">Updates</a></li>
          <li><a href="add-element.php">Add Elements</a></li>
          <li><a href="another_page.html">Admin</a></li>
          <li> <a href="delivered_elements.php">Delivered Elements</a> </li>
          <li><a href="contact.html">Contact Us</a></li>
        </ul>
      </div>
    </div>
    <div id="site_content">
      <div id="sidebar_container">
      </div>
      <div id="content">
        <h1>Delivered Elements</h1>

        <table style="width:100%; border-spacing:0;">
          <table><tr>
            <th style='background-color: mediumseagreen';>user_name</th>
            <th style='background-color: mediumseagreen';>item</th>
            <th style='background-color: mediumseagreen';>name</th>
            <th style='background-color: mediumseagreen';>contact1</th>
            <th style='background-color: mediumseagreen';>contact1</th>
            <th style='background-color: mediumseagreen';>address</th>
            <th style='background-color: mediumseagreen';>expery dt</th>
            <th style='background-color: mediumseagreen';>qty</th>
            <th style='background-color: mediumseagreen';>discription</th>
            <th style='background-color: darkslategrey';> Name</th>
            <th style='background-color: darkslategrey';> addres</th>
            <th style='background-color: darkslategrey';> contat</th>
          </tr>
          <?php
          $query1 = "SELECT * from delivered";
          $result = $con->query($query1);

        if ($result->num_rows > 0) {
        // output data of each row
        while($row = $result->fetch_assoc()) {
          $vol11 = $row["slno1"];
          $vol12 = $row["user_name"];
          $vol13 = $row["d_name"];
          $vol14 = $row["d_adr"];
          $vol15 = $row["d_contact"];
          $vol1 = $row["item"];
          $vol2 = $row["name"];
          $vol3 = $row["contact1"];
          $vol4 = $row["contact2"];
          $vol5 = $row["address"];
          $vol6 = $row["exday"];
          $vol7 = $row["qty"];
          $vol8 = $row["description"];
          echo "<tr>
                <td>".$vol12."</td>
                <td>".$vol1."</td>
                <td>".$vol2."</td>
                <td>".$vol3."</td>
                <td>".$vol4."</td>
                <td>".$vol5."</td>
                <td>".$vol6."</td>
                <td>".$vol7."</td>
                <td>".$vol8."</td>
                <td>".$vol13."</td>
                <td>".$vol14."</td>
                <td>".$vol15."</td></tr>";
           } }?>
        </table></table>
    <?php
    //
    //
    // Small  table
    //
    //
 if (isset($_POST['Remove-admin'])) {
     echo "///removing///";
     $ra = stripslashes($_REQUEST['Remove-admin']); // removes backslashes
echo "$ra";
     try {
       $query_del = "DELETE FROM item_list WHERE slno='$ra'";
       $result_del = $con->query($query_del);

     } catch (Exception $e) {

     }
   }
     ?>
      </div>
    </div>
    <div id="footer">
      <p><a href="index.html">Home</a> | <a href="examples.html">Examples</a> | <a href="page.html">A Page</a> | <a href="another_page.html">Another Page</a> | <a href="contact.html">Contact Us</a></p>
      <!-- <p>Copyright &copy; simplestyle_3 | <a href="http://validator.w3.org/check?uri=referer">HTML5</a> | <a href="http://jigsaw.w3.org/css-validator/check/referer">CSS</a> | <a href="http://www.html5webtemplates.co.uk">HTML5 Web Templates</a></p> -->
    </div>
    <p>&nbsp;</p>
  </div>
</body>
</html>
<br /><br /><br /><br />
<a href="logout.php">Logout</a>
<br /><br /><br /><br />
</div>
</body>
</html>
