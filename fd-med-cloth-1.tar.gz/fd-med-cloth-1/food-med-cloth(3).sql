-- phpMyAdmin SQL Dump
-- version 4.5.4.1deb2ubuntu2.1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Mar 04, 2020 at 06:37 AM
-- Server version: 5.7.28-0ubuntu0.16.04.2
-- PHP Version: 7.0.33-0ubuntu0.16.04.7

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `food-med-cloth`
--

-- --------------------------------------------------------

--
-- Table structure for table `items_to_pickup`
--

CREATE TABLE `items_to_pickup` (
  `slno1` int(11) NOT NULL,
  `user_name` varchar(50) NOT NULL,
  `d_name` varchar(50) NOT NULL,
  `d_adr` varchar(50) NOT NULL,
  `d_contact` varchar(50) NOT NULL,
  `item` varchar(50) NOT NULL,
  `name` varchar(50) NOT NULL,
  `contact1` varchar(50) NOT NULL,
  `contact2` varchar(50) NOT NULL,
  `address` varchar(50) NOT NULL,
  `exday` varchar(50) NOT NULL,
  `qty` varchar(50) NOT NULL,
  `description` varchar(500) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `items_to_pickup`
--

INSERT INTO `items_to_pickup` (`slno1`, `user_name`, `d_name`, `d_adr`, `d_contact`, `item`, `name`, `contact1`, `contact2`, `address`, `exday`, `qty`, `description`) VALUES
(12, 'qqq', 'abbbhi', 'd_tvc,kerala', '989582345', 'cloth', 'xx', 'xx', 'xx', 'xx', '', '1000kg', '                                 Enter description here...\r\n                                 '),
(13, 'qqq', 'abbbhi', 'd_tvc,kerala', '989582345', 'Food', 'xx', 'xx', 'xx', 'xx', '2020-02-18', 'xx', '                                 Enter description here...\r\n                                 ');

-- --------------------------------------------------------

--
-- Table structure for table `item_list`
--

CREATE TABLE `item_list` (
  `slno` int(11) NOT NULL,
  `item` varchar(50) DEFAULT NULL,
  `name` varchar(50) DEFAULT NULL,
  `contact1` varchar(50) DEFAULT NULL,
  `urgent` varchar(50) DEFAULT NULL,
  `contact2` varchar(50) DEFAULT NULL,
  `address` varchar(50) DEFAULT NULL,
  `exday` varchar(50) DEFAULT NULL,
  `qty` varchar(50) DEFAULT NULL,
  `description` varchar(500) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `item_list`
--

INSERT INTO `item_list` (`slno`, `item`, `name`, `contact1`, `urgent`, `contact2`, `address`, `exday`, `qty`, `description`) VALUES
(1, 'cloth', 'abhi', '8284878586', 'yes', '213513544', 'tvm, clt,attingal 123456', '12/10/2020', '5kg', 'good and old description'),
(3, 'Food', 'xx', 'xx', '', 'xx', 'xx', '', 'xx', '                                 Enter description here...\r\n                                 '),
(4, 'Food', 'xx', 'xx', '', 'xx', 'xx', '2020-01-07', 'xx', '                                 Enter description here...\r\n                                 '),
(6, 'Food', 'xx12', 'xx', '', 'xx', 'xx', '', 'xx', '                                 Enter description here...\r\n                                 '),
(7, 'med', 'aaa', '12345', 'yes', '321', 'tvm,  123456', '12/10/2020', '100kg', 'dzdc sfc fa f adc'),
(8, 'Food', '123qwee', 'xx', '', 'xx', 'qqqqqqqqqqqqqqq', '', 'xx', '                                 Enter description here...\r\n                                 '),
(9, 'Food', '123qwee', 'xx', '', 'xx', 'qqqqqqqqqqqqqqq', '', 'xx', '                                 Enter description here...\r\n                                 '),
(11, 'Food', 'qqqqpp', 'xx', '', 'xx', 'xx', '', 'xx', '                                 Enter description here...\r\n                                 '),
(12, 'cloth', 'xx', 'xx', '', 'xx', 'xx', '', '1000kg', '                                 Enter description here...\r\n                                 '),
(13, 'Food', 'xx', 'xx', '', 'xx', 'xx', '2020-02-18', 'xx', '                                 Enter description here...\r\n                                 ');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `level` varchar(10) NOT NULL,
  `email` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `trn_date` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `level`, `email`, `password`, `trn_date`) VALUES
(4, 'a', '10', 'a@a.com', '4124bc0a9335c27f086f24ba207a4912', '2020-01-04 12:39:13'),
(5, 'admin', '0', 'a@a.com', '21232f297a57a5a743894a0e4a801fc3', '2020-01-07 18:18:08'),
(7, 'vol', '1', 'a@a.com', '0acf8be1231e24946c3d10b649fb576f', '2020-01-08 08:48:01'),
(8, 'w', '2', 'aq@a.c', 'f1290186a5d0b1ceab27f4e77c0c5d68', '2020-01-08 11:47:36'),
(9, 'ww', '2', 'ww@q.com', 'ad57484016654da87125db86f4227ea3', '2020-02-08 14:53:32'),
(10, 'qqq', '2', 'qq@qq.com', 'b2ca678b4c936f905fb82f2733f5297f', '2020-02-23 12:11:41');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `items_to_pickup`
--
ALTER TABLE `items_to_pickup`
  ADD PRIMARY KEY (`slno1`);

--
-- Indexes for table `item_list`
--
ALTER TABLE `item_list`
  ADD PRIMARY KEY (`slno`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `item_list`
--
ALTER TABLE `item_list`
  MODIFY `slno` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;
--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
