<?php

include("auth.php"); //include auth.php file on all secure pages
?>
<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<title>Welcome Home</title>
<link rel="stylesheet" href="css/style1.css" />
</head>
<body>
<div class="form">
<p>Welcome <?php echo $_SESSION['username']; ?>!</p>
<p>This is secure area.</p>

<!DOCTYPE HTML>
<html>

<head>
  <title>simplestyle_3 - examples</title>
  <meta name="description" content="website description" />
  <meta name="keywords" content="website keywords, website keywords" />
  <meta http-equiv="content-type" content="text/html; charset=windows-1252" />
  <link rel="stylesheet" type="text/css" href="css/style1.css" />
</head>

<body>
  <div id="main">
    <div id="header">
      <div id="logo">
        <div id="logo_text">
          <!-- class="logo_colour", allows you to change the colour of the text -->
          <h1><a href="index.html">Donate <span class="logo_colour">Food Medicine Clothes</span></a></h1>
          <h2></h2>
        </div>
      </div>
      <div id="menubar">
        <ul id="menu">
          <!-- put class="selected" in the li tag for the selected page - to highlight which page you're on -->
          <li><a href="index.html">Home</a></li>
          <li class="selected"><a href="examples.html">Updates</a></li>
          <li><a href="add-element.php">Add Elements</a></li>
          <!-- <li><a href="another_page.html">Admin</a></li> -->
          <li><a href="contact.html">Contact Us</a></li>
        </ul>
      </div>
    </div>
    <div id="site_content">
      <!-- <div id="sidebar_container">
        <div class="sidebar">
          <div class="sidebar_top"></div>
          <div class="sidebar_item">
            <h3>Latest News</h3>
            <h4>New Website Launched</h4>
            <h5>January 1st, 2010</h5>
            <p>2010 sees the redesign of our website.....&nbsp;<a href="#">read more</a></p>
          </div>
          <div class="sidebar_base"></div>
        </div>
        <div class="sidebar">
          <div class="sidebar_top"></div>
          <div class="sidebar_item">
            <h3>Useful Links</h3>
            <ul>
              <li><a href="#">link 1</a></li>
              <li><a href="#">link 2</a></li>
              <li><a href="#">link 3</a></li>
              <li><a href="#">link 4</a></li>
            </ul>
          </div>
          <div class="sidebar_base"></div>
        </div>
        <div class="sidebar">
          <div class="sidebar_top"></div>
          <div class="sidebar_item">
            <h3>Search</h3>
            <form method="post" action="#" id="search_form">
              <p>
                <input class="search" type="text" name="search_field" value="Enter keywords....." />
                <input name="search" type="image" style="border: 0; margin: 0 0 -9px 5px;" src="style/search.png" alt="Search" title="Search" />
              </p>
            </form>
          </div>
          <div class="sidebar_base"></div>
        </div>
      </div> -->
      <div id="content">

        <h2>Latest Updates</h2>
        <!-- <p>Tables should be used to display data and not used for laying out your website:</p> -->


        <table style="width:130%; border-spacing:0;">
          <tr><th>Item</th><th>Location</th><th>Qty</th><th>loook up</th></tr>
        <?php

        require('db.php');
        $con = new mysqli("localhost","root","12","food-med-cloth");
          if ($con->connect_errno) {
              echo "Failed to connect to MySQL: (" . $con->connect_errno . ") " . $con->connect_error;
          }
          //$sql = "SHOW TABLES";

          //
          //
          // Main table
          //
          //
          $sql = "select * from item_list";  //edit your table name here
          // $res = $con->query($sql);
         if ($result = $con->query($sql)) {
             /* fetch associative array */
             while ($row = $result->fetch_assoc()) {
                 $field0name = $row["slno"];
                 $field1name = $row["item"];
                 $field2name = $row["address"];
                 $field3name = $row["qty"];
                 // $field4name = $row["col4"];
                 // $field5name = $row["col5"];
                 echo "
                        <tr>
                        <td>".$field1name."</td>
                        <td>".$field2name."</td>
                        <td>".$field3name."</td>
                        <td>
                            <form action='' method='post'>
                            <button class='btn btn-primary' type='submit' name='contact_him' value='".$field0name."'>check me</button>
                            </form>

                        </td>
                      </tr>";
             }
             /* free result set */
             $result->free();
         }
        ?></table>

           <?php
           //
           //
           // Small  table
           //
           //
        if (isset($_POST['contact_him'])) {
            echo "///ok///";
            $contact_him = stripslashes($_REQUEST['contact_him']); // removes backslashes
            echo "$contact_him";
            $query1 = "SELECT slno,item, name, address, exday, qty, description FROM item_list WHERE slno='$contact_him' ";
            $result = $con->query($query1);

      if ($result->num_rows > 0) {
          // output data of each row
          while($row = $result->fetch_assoc()) {
            $f0name = $row["item"];
            $f01name = $row["name"];
            $f1name = $row["address"];
            $f2name = $row["exday"];
            $f3name = $row["qty"];
            $f4name = $row["description"];
            $slno = $row["slno"];
            echo "<table><tr>
                   <th>item</th>
                   <th>name</th>
                   <th>address</th>
                   <th>exday</th>
                   <th>qty</th>
                   <th>description</th>
                   <th>Delivary location</th>
                 </tr>
                 <tr>
                 <td>".$f0name."</td>
                 <td>".$f01name."</td>
                 <td>".$f1name."</td>
                 <td>".$f2name."</td>
                 <td>".$f3name."</td>
                 <td>".$f4name."</td>
                 <td>
                 <form action='' method='post'>
                name<br/> <input type='text' name='d_name' value='abbbhi'>
               address<br/><input type='text' name='d_adr' value='d_tvc,kerala'>
               contact<br/><input type='text' name='d_contact' value='989582345'>
               <button class='btn btn-primary' type='submit' name='checkout'  value='".$slno."''>Order Now</button>
                 </form>
                 </td>
             </tr> </table>";
              // echo "id: " . $row["item"]. " - Name: " . $row["name"]. " " . $row["address"]. "<br>";
          }
      }
      else {
          echo "0 results error:202";
            }

    }
    ?>
<?php
//
//
// Send to volunter table
//
//

if (isset($_POST['checkout'])) {
    echo "///ok checkout///";
    $session_name = $_SESSION['username'];
    $slno_ = stripslashes($_POST['checkout']); // removes backslashes
    $d_name = stripslashes($_POST['d_name']); // removes backslashes
    $d_adr = stripslashes($_REQUEST['d_adr']);
    $d_contact = stripslashes($_REQUEST['d_contact']);
    $checkout = stripslashes($_REQUEST['checkout']);
    // echo "$d_name";
    //
    // echo "$slno_";
    $sql2 = "SELECT * FROM item_list WHERE slno='$slno_'";  //edit your table name here
    // $res = $con->query($sql);
   if ($result = $con->query($sql2)) {
       /* fetch associative array */
       while ($row = $result->fetch_assoc()) {
         $f0name1 = $row["item"];
         $f01name1 = $row["name"];
         $c1 = $row["contact1"];
         $c2 = $row["contact2"];
         $f1name1 = $row["address"];
         $f2name1 = $row["exday"];
         $f3name1 = $row["qty"];
         $f4name1 = $row["description"];
         $slno1 = $row["slno"];


          $query23 = "INSERT into items_to_pickup (slno1, user_name, d_name, d_adr, d_contact, item, name, contact1, contact2, address, exday, qty, description) VALUES ('$slno1','$session_name','$d_name','$d_adr','$d_contact','$f0name1', '$f01name1', '$c1','$c2','$f1name1', '$f2name1','$f3name1','$f4name1')";

          // $result = mysqli_query($con,$query);
          // echo "$result";
          if (mysqli_query($con, $query23)) {
              echo "ORDER Placed successfully";
          } else {
              echo "Error 301: " . $query23 . "<br>" . mysqli_error($con);
          }
       }

  }
}
 ?>

      </div>
    </div>
    <div id="footer">
      <p><a href="index.html">Home</a> | <a href="logout.php">Logout</a>
         <!-- | <a href="page.html">A Page</a> | <a href="another_page.html">Another Page</a> | <a href="contact.html">Contact Us</a> -->
       </p>
      <!-- <p>Copyright &copy; simplestyle_3 | <a href="http://validator.w3.org/check?uri=referer">HTML5</a> | <a href="http://jigsaw.w3.org/css-validator/check/referer">CSS</a> | <a href="http://www.html5webtemplates.co.uk">HTML5 Web Templates</a></p> -->
    </div>
    <p>&nbsp;</p>
  </div>
</body>
</html>





<br /><br /><br /><br />
<!-- <p><a href="dashboard.php">Dashboard</a></p>
<a href="logout.php">Logout</a>


<br /><br /><br /><br /> -->

</div>
</body>
</html>
