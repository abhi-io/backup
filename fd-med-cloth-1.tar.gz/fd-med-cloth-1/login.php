

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.1//EN" "http://www.w3.org/TR/xhtml11/DTD/xhtml11.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link rel="stylesheet" type="text/css" href="style.css" />
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
<title>food med cloth</title>
</head>

<body>
    <div id="page">

        <div id="header">
            <ul>
           	   	<li><a href="index.html">Home</a></li>

            </ul>
            <h1>FoodMedCloth</h1>
        </div>
  <div class="dotted_line"></div>
        <div id="main">

					<?php

						require('db.php');
					    // If form submitted, insert values into the database.
					    if (isset($_POST['username'])){

							$username = stripslashes($_REQUEST['username']); // removes backslashes
							$username = mysqli_real_escape_string($con,$username); //escapes special characters in a string
							$password = stripslashes($_REQUEST['password']);
							$password = mysqli_real_escape_string($con,$password);

						//Checking is user existing in the database or not
					        $query = "SELECT * FROM `users` WHERE username='$username' and password='".md5($password)."'";
							$result = mysqli_query($con,$query) or die(mysql_error());
					// check for admin / volunteeer
						$rows = mysqli_num_rows($result);
					        if($rows==1){
							$member = mysqli_fetch_assoc($result);
							if(0 == $member['level']) { // some way of identifying an admin
													session_start();
									$_SESSION['username'] = $username;
									header("location: admin.php");
									exit;
							} elseif ('2' == $member['level']) {
									// volunter
									session_start();
									$_SESSION['username'] = $username;
									header("location: index.php");
									exit;

							} elseif ('1' == $member['level']) {
									// volunter
									session_start();
									$_SESSION['username'] = $username;
									header("location: volunter.php");
									exit;
							}
							 elseif ('10' == $member['level']) {
									// Blocked
									echo "<div class='form'><h3>User is BLOCKED.</h3><br/>Click here to <a href='login.php'>Login</a></div>";
									exit;
							}
							 else {

							}

					        }else{
									echo "<div class='form'><h3>Username/password is incorrect.</h3><br/>Click here to <a href='login.php'>Login</a></div>";
									}
					}
					?>
					<div class="row justify-content-center">
					  <div class="col-md-4">
							<h1 class="text-white text-center">Login</h1>
							<br>
							<form  method="post" action="" name="login">
                <fieldset class="form-group">
                  <input type="text" class="inp form-control" name="username" placeholder="Username" value="<?php echo $username; ?>">
                </fieldset>
                <fieldset class="form-group">
                  <input type="password" class="inp form-control" name="password" placeholder="Password" value="<?php echo $pass; ?>">
                </fieldset>
                <button type="submit"  name="submit" class="btn login-btn btn-light" style="width:100%">Login</button>
              </form>
							<br>
							<p>Not registered yet? <a href='registration.php'>Register Here</a></p>
					  </div>
					</div>


           	<div class="main_bottom"></div>

        </div>


        <div class="dotted_line"></div>
        <div id="footer">
        <p>
      </div>

        </div>
</body>
</html>
