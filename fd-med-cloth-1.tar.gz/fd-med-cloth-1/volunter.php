<?php

include("auth.php"); //include auth.php file on all secure pages
require('db.php');
?>
<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<title>Welcome Home</title>
<link rel="stylesheet" href="css/style1.css" />
</head>
<body>
<div class="form">
<p>Welcome <?php echo $_SESSION['username']; ?>!</p>
<p>This is secure area.</p>

<!DOCTYPE HTML>
<html>

<head>
  <title>food-med-cloth</title>
  <meta name="description" content="website description" />
  <meta name="keywords" content="website keywords, website keywords" />
  <meta http-equiv="content-type" content="text/html; charset=windows-1252" />
  <link rel="stylesheet" type="text/css" href="css/style1.css" />
</head>

<body>
  <i>
  <div id="main">
    <div id="header">
      <div id="logo">
        <div id="logo_text">
          <!-- class="logo_colour", allows you to change the colour of the text -->
          <h1><a href="index.html">WE <span class="logo_colour">are caring</span></a></h1>
          <h2> volunters </h2>
        </div>
      </div>
      <div id="menubar">
        <ul id="menu">
          <!-- put class="selected" in the li tag for the selected page - to highlight which page you're on -->
          <li><a href="index.html">Home</a></li>
          <li class="selected"><a href="examples.html">Updates</a></li>
          <!-- <li><a href="add-element.php">Add Elements</a></li> -->
          <!-- <li><a href="another_page.html">Admin</a></li> -->
          <li><a href="contact.html">Contact Us</a></li>
        </ul>
      </div>
    </div>
    <div id="site_content">
      <div id="sidebar_container">

      </div>
      <div id="content">

        <h2>Updates to Volunters</h2>
        <p>volunter page to inform volunters about new orders</p>

        <table style="width:100%; border-spacing:0;">
          <table><tr>
                  <th colspan = "9" style="text-align: center;">Pick Up Loction</th>
                  <th colspan = "3" style="text-align: center;">Delever Loction</th>
                  <th colspan = "1" style="text-align: center;">status</th>
                </tr>
                <tr>
                 <th>user_name</th>
                 <th>item</th>
                 <th>name</th>
                 <th>contact1</th>
                 <th>contact1</th>
                 <th>address</th>
                 <th>expery dt</th>
                 <th>qty</th>
                 <th>discription</th>
                 <th> Name</th>
                 <th> addres</th>
                 <th> contat</th>
                 <th>Enguage</th>
               </tr>
        <?php
        // ini_set('display_errors', 1);
        // ini_set('display_startup_errors', 1);
        // error_reporting(E_ALL);

        $con = new mysqli("localhost","root","12","food-med-cloth");
          if ($con->connect_errno) {
              echo "Failed to connect to MySQL: (" . $con->connect_errno . ") " . $con->connect_error;
          }
          //$sql = "SHOW TABLES";

          //
          //
          // show items to picup
          //
          //
          $sql = "select * from items_to_pickup";  //edit your table name here
          // $res = $con->query($sql);
         if ($result = $con->query($sql)) {
             /* fetch associative array */
             while ($row = $result->fetch_assoc()) {
               $vol11 = $row["slno1"];
               $vol12 = $row["user_name"];
               $vol13 = $row["d_name"];
               $vol14 = $row["d_adr"];
               $vol15 = $row["d_contact"];
               $vol1 = $row["item"];
               $vol2 = $row["name"];
               $vol3 = $row["contact1"];
               $vol4 = $row["contact2"];
               $vol5 = $row["address"];
               $vol6 = $row["exday"];
               $vol7 = $row["qty"];
               $vol8 = $row["description"];
               $vol9 = $row["slno1"];
                 echo "
                        <tr>
                        <td>".$vol12."</td>
                        <td>".$vol1."</td>
                        <td>".$vol2."</td>
                        <td>".$vol3."</td>
                        <td>".$vol4."</td>
                        <td>".$vol5."</td>
                        <td>".$vol6."</td>
                        <td>".$vol7."</td>
                        <td>".$vol8."</td>
                        <td>".$vol13."</td>
                        <td>".$vol14."</td>
                        <td>".$vol15."</td>
                        <td>
                            <form action='' method='post'>
                            <button type='submit' name='vol_page' value='".$vol11."'>DETAILS</button>
                            </form>

                        </td>
                      </tr>";
             }
             /* free result set */
             $result->free();
         }
        ?></table>


           <?php
           //
           //
           // Small  table
           //
           //
        if (isset($_POST['vol_page'])) {

  echo "<table style='width:100%; border-spacing:0;'>
        <tr>
        <th colspan = '9' style='text-align: center;'>Pick Up Loction</th>
        <th colspan = '3' style='text-align: center; background-color: darkslategrey;'>Delever Loction</th>
        <th colspan = '1' style='text-align: center;'>status</th>
        </tr>";
            $vol_page = stripslashes($_REQUEST['vol_page']); // removes backslashes
            // echo "$vol_page";
            $query1 = "SELECT * from items_to_pickup WHERE slno1='$vol_page' ";
            $result = $con->query($query1);

      if ($result->num_rows > 0) {
          // output data of each row
          while($row = $result->fetch_assoc()) {
            $vol11x = $row["slno1"];
            $vol12 = $row["user_name"];
            $vol13 = $row["d_name"];
            $vol14 = $row["d_adr"];
            $vol15 = $row["d_contact"];
            $vol1 = $row["item"];
            $vol2 = $row["name"];
            $vol3 = $row["contact1"];
            $vol4 = $row["contact2"];
            $vol5 = $row["address"];
            $vol6 = $row["exday"];
            $vol7 = $row["qty"];
            $vol8 = $row["description"];
            $vol9 = $row["slno1"];
            echo "<tr>
             <th style='background-color: mediumseagreen';>user_name</th>
             <th style='background-color: mediumseagreen';>item</th>
             <th style='background-color: mediumseagreen';>name</th>
             <th style='background-color: mediumseagreen';>contact1</th>
             <th style='background-color: mediumseagreen';>contact1</th>
             <th style='background-color: mediumseagreen';>address</th>
             <th style='background-color: mediumseagreen';>expery dt</th>
             <th style='background-color: mediumseagreen';>qty</th>
             <th style='background-color: mediumseagreen';>discription</th>
             <th style='background-color: darkslategrey';> Name</th>
             <th style='background-color: darkslategrey';> addres</th>
             <th style='background-color: darkslategrey';> contat</th>
             <th>Enguage</th>
           </tr>
           <tr>
                 <td>".$vol12."</td>
                 <td>".$vol1."</td>
                 <td>".$vol2."</td>
                 <td>".$vol3."</td>
                 <td>".$vol4."</td>
                 <td>".$vol5."</td>
                 <td>".$vol6."</td>
                 <td>".$vol7."</td>
                 <td>".$vol8."</td>
                 <td>".$vol13."</td>
                 <td>".$vol14."</td>
                 <td>".$vol15."</td>
                 <td><form method='post'>
                  <button type=submit name='checked' value='$vol11x' style='width:100%' >OK</button>
                 </form></td>


               </tr>";
              // echo "id: " . $row["item"]. " - Name: " . $row["name"]. " " . $row["address"]. "<br>";
          }


      }
      else {
          // echo "-0 results error:2026";
            }

    }
    if (isset($_POST['checked'])) {
      $vol00 = stripslashes($_REQUEST['checked']);
      echo $vol00;
      try {
        $query_del = "DELETE FROM items_to_pickup WHERE slno1='$vol00'";
        $result_del = $con->query($query_del);
        $query_de2 = "DELETE FROM item_list WHERE slno='$vol00'";
        $result_de2 = $con->query($query_de2);

      } catch (Exception $e) {

      }
    }




    ?>


<script>
function myFunction() {
  alert("Order Complete");
  // window.location.reload();
}
</script>

</table>


      </div>
    </div>
    <div id="footer">
      <p><a href="index.html">Home</a> | <a href="examples.html">Examples</a> | <a href="page.html">A Page</a> | <a href="another_page.html">Another Page</a> | <a href="contact.html">Contact Us</a></p>

    </div>
    <p>&nbsp;</p>
  </div>
</body>
</html>





<br /><br /><br /><br />
<p><a href="dashboard.php">Dashboard</a></p>
<a href="logout.php">Logout</a>


<br /><br /><br /><br />

</div>
</body>
</html>
