Because I can never get a straight answer for a simple solution to include an image in a block with a easy-to-use interface for non-technical folk.

Image block is a module where one can create a simple block that includes an image. This module also integrates with <a href="http://drupal.org/project/imagecache">Imagecache</a> for dynamic image sizing and manipulation.

How to use:
1. Enable Image block module.</li>
2. Navigate to admin/build/block.</li>
3. Click the "Add image block" link in the local tasks menu.</li>
4. Configure your image block, and save.
