<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>KTU Best moments 2015</title>
<link rel="stylesheet" type="text/css" href="style.css" />
</head>
<body>
<div id="container">
	<div id="header">
	    <div id="picture">
            <h1>Best 10 KTU Trolles </h1>
            <h2>2015 batch &#x2665;</h2>
        </div>
    </div>
    <div id="main">
    <div id="leftcol_container">
    	<div class="leftcol">
        	<h2>Articles</h2>
        	<ul>
            	<li><a href="https://ktu.edu.in/home.htm">KTU </a></li>
            	<li><a href="https://ktu.edu.in/eu/core/announcements.htm">Announcements</a></li>
            	<li><a href="https://ktu.edu.in/eu/res/viewResults.htm">Results</a></li>
            	<li><a href="#">Result Analysis</a></li>
            	<li><a href="#">Search Submission</a></li>
            	<li><a href="#">Norms And Rules</a></li>
                <li><a href="#">Academic Audit</a></li>
                <li><a href="#">CERD Activities</a></li>
                <li><a href="#">Examination</a></li>
                <li><a href="#">Time Table</a></li>
                <li><a href="#">Gallery</a></li>
                <li><a href="#">Board of Governors</a></li>
                <li><a href="#">Syndicate</a></li>
                <li><a href="#">Events</a></li>
                <li><a href="https://ktu.edu.in/eu/core/contactUs.htm">Contact Us</a></li>
                
            </ul>
        	<p>&nbsp;</p>
        	<h2>Most Popular</h2>
            <ul>
	            <li><a href="#">Best Univercity</a></li>
                <li><a href="#">Best Engineering College</a></li>
                <li><a href="#">Best Cource</a></li>
                <li><a href="#"> &nbsp</a></li>
                <li><a href="#"> &nbsp</a></li>
                <li><a href="#"> &nbsp</a></li>
                <li><a href="#">&nbsp</a></li>
            	<li><a href="#">&nbsp </a></li>
            	<li><a href="#">&nbsp</a></li>
            	<li><a href="#">&nbsp</a></li>
            	<li><a href="#">&nbsp</a></li>
            	<li><a href="#">&nbsp</a></li>
                <li><a href="#">&nbsp</a></li>
                <li><a href="#">&nbsp</a></li>
                <li><a href="#">&nbsp</a></li>
            </ul>
            <p>&nbsp;</p>
            <p>&nbsp;</p>
            <p>&nbsp;</p>
            <p>&nbsp;</p>
            <a href="#">UPLOAD</a>
      </div>
      <div class="leftcol_bottom"></div>
      </div>
        <div id="maincol_container">
        <div class="maincol">
<?php
   session_start();
   include ('connected.php');
   // Page was not reloaded via a button press
   if (!isset($_POST['add'])) {
       $_SESSION['attnum'] = $_SESSION['attnumx']; // Reset counter
      $x=$_SESSION['attnum'];
       if ($x <= 1 ){
         $_SESSION['attnum']=1;
         $_SESSION['attnumx']=1;
         $x = 1;
       }
        print_img($x);
   }
   elseif (!isset($_POST['sub'])) {
       $_SESSION['attnumx'] = $_SESSION['attnum']; // Reset counter
       $x= $_SESSION['attnumx'];
       if ($x <= 1){
         $_SESSION['attnumx']=1;
         $_SESSION['attnum']=1;
         $x = 1;
       }
        print_img($x);
   }
   function print_img($img_no=1){
     echo $img_no;
     
     include ('connected.php');
     $ret=mysqli_query( $conn, "SELECT * FROM trollimg WHERE no='$img_no' ") or die("Could not execute query: " .mysqli_error($conn));
   	$result_img = mysqli_fetch_assoc($ret);
   	if(!$result_img) {		header("Location: error_no_img.php");			}
   	else {
   			// echo "okkkw";
   			echo "<br>";
   			echo '<img style="height: 500px;width: 435px;" src="data:image/jpg;base64,'.base64_encode( $result_img['image'] ).'"/>';
     }
   }
?>

  </div>
      
        <div style="text-align: center;position: absolute;" class="maincol">
        
		<form  method='post'>
						<input name='sub' type="submit" value='Previous' style="  background-color: #4CAF50;  border: none;  color: white; padding: 15px 32px;  text-align: center;  text-decoration:none;  display: inline-block;  font-size:16px;  margin: 4px 2px;  cursor: pointer;">
						 <?php  --$_SESSION['attnumx'] ?>
						<input name='add' type="submit" value='Next'style="  background-color: #4CAF50; border: none;  color: white; padding: 15px 32px;  text-align: center;  text-decoration:none; display: inline-block;  font-size: 16px; margin: 4px 2px;  cursor: pointer;">
						 <?php  ++$_SESSION['attnum'] ?>
		</form>
			
        </div>
				<div class="maincol">
				<h2>curtosy</h2>
				<p>troll ktu</p>
				</div>
	
        <div class="maincol_bottom"></div>
        </div>
				
     <div id="rightcol_container">
        <div class="rightcol">
        <h2>Categories</h2>
        	<ul>
            	<li><a href="#">.</a></li>
            	<li><a href="#">.</a></li>
            	<li><a href="#">.</a></li>
            	<li><a href="#">.</a></li>
            	<li><a href="#">.</a></li>
            	<li><a href="#">.</a></li>
            </ul>
        </div>
        <div class="rightcol_bottom"></div>
        <div class="rightcol">
        <h2>Blogs</h2>
        	<ul>
            	<li><a href="#">.</a></li>
            	<li><a href="#">The Design Blog</a></li>
            	<li><a href="#">Designs4all</a></li>
            	<li><a href="#">Free XHTML Templates</a></li>
            	<li><a href="#">WebGraphics</a></li>
            	<li><a href="#">HowToWeb</a></li>
            </ul>
        </div>
        <div class="rightcol_bottom"></div>
        <div class="rightcol">
        <h2>Links</h2>
        	<ul>
            	<li><a href="#">Google</a></li>
            	<li><a href="#">Yahoo</a></li>
            	<li><a href="#">Bing</a></li>
            	<li><a href="#">Ask</a></li>
            	<li><a href="#">Dogpile</a></li>
            	<li><a href="#">Altavista</a></li>
            </ul>
        </div>
        <div class="rightcol_bottom"></div>
       <div class="rightcol">
        <h2>Most Recent</h2>
        	<ul>
            	<li><a href="#">Web Designers</a></li>
            	<li><a href="#">Internet Marketing</a></li>
            	<li><a href="#">Easy SEO</a></li>
            	<li><a href="#">Web Graphics</a></li>
            	<li><a href="#">Flash Animation</a></li>
            </ul>
        </div>
        <div class="rightcol_bottom"></div>
        </div>
        <div class="clear"></div>
         <div id="footer"><h3><a href="https://www.facebook.com/groups/troll.ktu/">courtesy: Troll KTU</a></div>
  </div>
</div>
</body>
</html>
