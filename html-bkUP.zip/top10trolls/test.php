<?php
   session_start();
   include ('connected.php');
   // Page was not reloaded via a button press
   if (!isset($_POST['add'])) {
       $_SESSION['attnum'] = $_SESSION['attnumx']; // Reset counter
      $x=$_SESSION['attnum'];
       if ($x <= 1 ){
         $_SESSION['attnum']=1;
         $_SESSION['attnumx']=1;
         $x = 1;
       }
        print_img($x);
   }
   elseif (!isset($_POST['sub'])) {
       $_SESSION['attnumx'] = $_SESSION['attnum']; // Reset counter
       $x= $_SESSION['attnumx'];
       if ($x <= 1){
         $_SESSION['attnumx']=1;
         $_SESSION['attnum']=1;
         $x = 1;
       }
        print_img($x);
   }
   function print_img($img_no=1){
     echo $img_no;
     
     include ('connected.php');
     $ret=mysqli_query( $conn, "SELECT * FROM trollimg WHERE no='$img_no' ") or die("Could not execute query: " .mysqli_error($conn));
   	$result_img = mysqli_fetch_assoc($ret);
   	if(!$result_img) {		header("Location: test.php");			}
   	else {
   			echo "okkkw";
   			echo "<br>";
   			echo '<img style="height: 500px;width: 435px;" src="data:image/jpg;base64,'.base64_encode( $result_img['image'] ).'"/>';
     }
   }
?>
<form method='post'>
<input name='add' type="submit" value='+'>
<h3><em>att- <?php  ++$_SESSION['attnum'] ?>: </em></h3>
<input name='sub' type="submit" value='-'>
<h3><em>sub- <?php  --$_SESSION['attnumx'] ?>: </em></h3>
</form>
