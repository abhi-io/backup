import os
from flask import Flask, flash, request, redirect, url_for, render_template, send_from_directory
from werkzeug.utils import secure_filename
import textract, os
from fuzzywuzzy import fuzz

app = Flask(__name__)
UPLOAD_FOLDER= os.getcwd()+'/resume_pool'
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER
job_des=''
file=''

ALLOWED_EXTENSIONS = {'txt', 'pdf', 'png', 'dox', 'docx', 'odt'}
@app.route('/')
def index():
   return render_template('index.html')
def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS
@app.route('/view/<pdfname>')
def profile(pdfname):
    print(pdfname)
    return send_from_directory(UPLOAD_FOLDER, pdfname)
@app.route('/delete/<pdfname>')
def delete(pdfname):
    os.chdir(UPLOAD_FOLDER)
    os.remove(pdfname)
    os.chdir('..')
    print(pdfname,"DELETED")
    return redirect("/")

def process():
    print("<<<process>>>")
    new_dict = {}
    dict = {}
    print(job_des)
    # try:
    if True:
        # job_des = "CSS, HTML Strong programming language skills using Java or python."

        os.chdir(UPLOAD_FOLDER)
        all_files= [f for f in os.listdir('.') if os.path.isfile(f) and f.endswith('.pdf') or f.endswith('.txt') or f.endswith('.py')]
        for pdf_file in all_files:
            print(pdf_file,"<<<<<")
            try:

                text = textract.process(pdf_file).decode('utf-8')
                Str1 = text
                Str2 = job_des
                # print(Str2)

                Ratio = fuzz.ratio(Str1.lower(),Str2.lower())
                Partial_Ratio = fuzz.partial_ratio(Str1.lower(),Str2.lower())
                Token_Sort_Ratio = fuzz.token_sort_ratio(Str1,Str2)
                Token_Set_Ratio = fuzz.token_set_ratio(Str1,Str2)
                total=Ratio+Partial_Ratio+Token_Sort_Ratio+Token_Set_Ratio+Token_Set_Ratio
                print("---------",total)
                dict.update( {total : pdf_file} )

            except Exception as e:
                print("****ERROR****")
        os.chdir('..')
        global dict
        print(dict, os.getcwd())
        # new_dict = OrderedDict(sorted(dict.keys(), key=lambda t: t[0]))
        print("[****]",dict)

@app.route('/check', methods=['GET', 'POST'])
def upload_file():
    if request.method == 'POST':
        # check if the post request has the file part
        if 'file' not in request.files:
            flash('No file part')
            return redirect(request.url)
        file = request.files['file']
        job_des = request.form['text']
        global job_des
        if(len(job_des) == 0):
            print(len(job_des),"///////////empty///////////")
            return redirect(request.url)
        print(file,job_des,"<<<<<<<<<<<<<<")
        if file and allowed_file(file.filename):
            filename = secure_filename(file.filename)
            file.save(os.path.join(app.config['UPLOAD_FOLDER'], filename))

            process()
            print("*******************************************///////////")
            list1 =sorted(dict.items(), reverse = True)
            # for k, v in sorted(dict.items())
            print("list1")
            print(list1)
            return render_template('t1.html', dates=list1)
        else:
            process()
            print("*******************************************///////////")
            list1 =sorted(dict.items(), reverse = True)
            print("list1")
            print(list1)
            return render_template('t1.html', dates=list1)



if __name__ == "__main__":
    # app.run(debug = True)
    # app.run(host = '0.0.0.0')
    app.run(host = '0.0.0.0',port=5000,debug = True)
